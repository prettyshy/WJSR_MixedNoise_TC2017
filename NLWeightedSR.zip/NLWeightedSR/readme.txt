This matlab code corresponding to the paper
L. Liu, L. Chen, C. L. P. Chen, Y. Y. Tang, and C. M. Pun, "Weighted Joint Sparse Representation for Removing Mixed Noise in Image," 
IEEE Transactions on Cybernetics, vol. 47, pp. 600-611, 2017.

Please run the main_NLGroupWeightSR.m code to begin your test. Good luck!

Please cite this paper if you use this code. 

For further information, please contact: lichenghnu@gmail.com